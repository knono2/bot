const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const Snoowrap = require('snoowrap');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

const redditClient = new Snoowrap({
  userAgent: 'kai',
  clientId: 'CVtbgp1GJJgNhBEuZJx4qw',
  clientSecret: 'j5dC9w1xTkJEuwzdnOTjxShj5olctw',
  username: 'its_knono2',
  password: 'Lukas12Lukas12'
});

// Variablen
const prefix = '.'; // Hier kannst du dein Präfix definieren
const willkommensNachricht = 'Willkommen auf dem Server!'; // Die Willkommensnachricht, die du senden möchtest
const willkommensKanalId = '1244215949373083649'; // Die ID des Kanals, in den die Willkommensnachricht gesendet werden soll
const nsfwRoleId = '1244353275914883212'; // Die ID der NSFW-Rolle
const adminRoleId = '1244222673488187444'; // Die ID der Admin-Rolle


// Das macht der Bot, wenn er online geht
client.once('ready', () => {
  console.log(`Bot ist eingeloggt als ${client.user.tag}!`);

  // Setze die Aktivität des Bots
  client.user.setActivity('play with code', { type: ActivityType.Playing });
});

// Ignoriere Nachrichten von Bots, einschließlich dem eigenen Bot
client.on('messageCreate', (message) => {
  if (message.author.bot) return;

  // Überprüfe, ob die Nachricht mit dem Präfix beginnt
  if (!message.content.startsWith(prefix)) return;

  // Split message content into command and args
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // Handle different commands
  if (command === 'ping') {
    message.reply('Pong!');
  } else if (command === 'hello') {
    message.reply('Hallo!');
  } else if (command === 'help') {
    message.reply('Verfügbare Befehle: ping, hello, help, roll, nsfw, delete, deleteall');
  } else if (command === 'roll') {
    const roll = Math.floor(Math.random() * 100) + 1;
    message.reply(`Du hast eine ${roll} gewürfelt!`);
  }
});

// Bilder
client.on('messageCreate', async (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'nsfw') {
    // Überprüfen, ob der Absender die NSFW-Rolle hat
    if (!message.member.roles.cache.has(nsfwRoleId)) {
      return message.reply('Du hast nicht die erforderliche Berechtigung, um diesen Befehl auszuführen.');
    }

    const nsfwSubreddits = ['r/HENTAI_GIF', 'r/hentai']; // Liste der NSFW-Subreddits
    const randomSubreddit = nsfwSubreddits[Math.floor(Math.random() * nsfwSubreddits.length)];

    try {
      const posts = await redditClient.getSubreddit(randomSubreddit).getHot({ limit: 10 });
      const nsfwPosts = posts.filter(post => post.over_18);

      if (nsfwPosts.length > 0) {
        const randomPost = nsfwPosts[Math.floor(Math.random() * nsfwPosts.length)];
        message.channel.send(randomPost.url);
      } else {
        message.channel.send('Es konnten keine NSFW-Bilder gefunden werden.');
      }
    } catch (error) {
      console.error('Fehler beim Abrufen der Reddit-Posts:', error);
      message.channel.send('Es ist ein Fehler aufgetreten.');
    }

    // Nachricht des Benutzers löschen
    message.delete();
  }
});

// Nachricht, wenn ein Spieler dem Server beitritt
client.on('guildMemberAdd', (member) => {
  const willkommensKanal = member.guild.channels.cache.get(willkommensKanalId);
  if (!willkommensKanal) return;

  willkommensKanal.send(`${member.user.tag} ist dem Server beigetreten. ${willkommensNachricht}`);
});

// Befehl zum Löschen einer bestimmten Anzahl von Nachrichten im aktuellen Kanal
client.on('messageCreate', async (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'delete') {
    // Überprüfen, ob der Absender die Admin-Rolle hat
    if (!message.member.roles.cache.has(adminRoleId)) {
      return message.reply('Du hast nicht die erforderliche Berechtigung, um diesen Befehl auszuführen.');
    }

    const deleteCount = parseInt(args[0], 10);

    if (!deleteCount || deleteCount < 1 || deleteCount > 100) {
      return message.reply('Bitte gib eine Zahl zwischen 1 und 100 an.');
    }

    try {
      const fetched = await message.channel.messages.fetch({ limit: deleteCount });
      message.channel.bulkDelete(fetched);
      message.reply(`${deleteCount} Nachrichten wurden gelöscht.`);
    } catch (error) {
      console.error('Fehler beim Löschen von Nachrichten:', error);
      message.reply('Beim Löschen von Nachrichten ist ein Fehler aufgetreten.');
    }

    // Nachricht des Benutzers löschen
    message.delete();
  }

  if (command === 'deleteall') {
    // Überprüfen, ob der Absender die Admin-Rolle hat
    if (!message.member.roles.cache.has(adminRoleId)) {
      return message.reply('Du hast nicht die erforderliche Berechtigung, um diesen Befehl auszuführen.');
    }

    // Nachrichten in allen Kanälen löschen
    message.guild.channels.cache.forEach(async (channel) => {
      if (channel.type === 'GUILD_TEXT') { // Nur Textkanäle berücksichtigen
        try {
          const fetchedMessages = await channel.messages.fetch();
          channel.bulkDelete(fetchedMessages);
        } catch (error) {
          console.error('Fehler beim Löschen von Nachrichten:', error);
          message.reply(`Beim Löschen von Nachrichten in ${channel.name} ist ein Fehler aufgetreten.`);
        }
      }
    });

    // Rückmeldung senden
    message.reply('Alle Nachrichten wurden erfolgreich gelöscht.');

    // Nachricht des Benutzers löschen
    message.delete();
  }
});


//der bot tocken
client.login("MTE5MzIxNzI4OTUzNzk5MDY4Nw.GcwpHv.GEAbbtP9EFnEC6RRjHbdMPseEGOFoDiu3Nl8t0");